This directory contains third-party libraries.

    ~~  The MRPT Library  ~~
    Jose Luis Blanco, FEB-2008


