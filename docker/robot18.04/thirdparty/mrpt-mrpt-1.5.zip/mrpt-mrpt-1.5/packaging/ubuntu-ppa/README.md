This directory is intended to hold the modified version of `debian/control.in`,
such that it does not cause problems with old versions of Ubuntu in PPA.
